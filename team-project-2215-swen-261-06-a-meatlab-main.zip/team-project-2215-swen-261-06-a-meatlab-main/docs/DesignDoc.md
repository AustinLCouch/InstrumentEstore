---
geometry: margin=1in
---
# PROJECT Design Documentation

## Team Information
* Team name: Meatlab
* Team members
  * Austin Couch | alc9026
  * Gabriel Furtado Noll | gf7798
  * Gregory Ojiem | gro3228
  * Ryan Healy | rmh1692
  * Ricky Gupta | rg4825

## Executive Summary

This is a summary of the project.

### Purpose

This project exists as the implementation of an e-store where users could purchase instruments. There are two main groups of users we want to cater to -- customers and the owner. 

On the customer side, they should be able to login to an account tied to their cart, browse for products (i.e. musical instruments), search for a specific product, add/remove products to/from their cart, and finally check out what they have in their cart.

As for the owner, they should be able to login to their specific admin account, track inventory of all products on the site (including marking a product as unavailable), and add/remove/edit items within inventory.

### Glossary and Acronyms

| Term | Definition             |
| ---- | ---------------------- |
| SPA  | Single Page            |
| MVP  | Minimum Viable Product |



## Requirements

This section describes the features of the application.

<!-- > _In this section you do not need to be exhaustive and list every
> story.  Focus on top-level features from the Vision document and
> maybe Epics and critical Stories._ -->

### Definition of MVP
<!-- > _Provide a simple description of the Minimum Viable Product._ 

Our e-store offers the perfect solution for small business owners. Our site provides the owners with the ability to sell their products at ease. They can manage the inventory they keep and customers can purchase with the intent to have the items shipped anywhere.
// -->
Small business owners have a very unique lifestyle. They have their craft, and then they have the business of their craft. E-commerce has revolutionized peoples' ability to sell their products with ease. But every business is different. Different types of products need different types of workflows beyond just inventory and a shopping cart. Many small businesses opt for custom software instead of a platform like Etsy or Shopify. That's where we come in.

### MVP Features
<!-- >_Provide a list of top-level Epics and/or Stories of the MVP._ 

- Minimal Authentication for customer/e-store owner login and logout. 
- Data persistence 
- Owner Inventory Management
- Product Lookup
- Customer Delivery / Shipping Options
- Customer Shopping Cart Management
- Customer Purchase Process

// -->

The Product Owner desires a minimal viable product (MVP) which includes these features:

- **Minimal Authentication for customer/e-store owner login & logout**
	- The server will (admittedly insecurely) trust the browser of who the user is. A simple username to login is all that is minimally required.
		-  Assume a user logging in as **admin** is the e-store owner.
	- The MVP does not expect full credential and session management, although the system will look different depending on who is logged in. 

- **Customer functionality**
	- Customer can see list of products
	- Customer can search for a product
	- Customer can add/remove an item to their shopping cart
	- Customer can proceed to check out their items for purchase

- **Inventory Management**
	- E-Store owners can add, remove and edit the data on the inventory

- **Data Persistence**
	- The system must save everything to files such that the next user will see a change in the inventory based on the previous user's actions. 
		- If a customer had something in their shopping cart and logged out, they should see the same items in their cart when they log back in.

- **Your 10% feature**
	- Proposed to the Product Owner by end of Sprint 1, and then build it into the product throughout the semester. See below for more details.

### 10% Enhancement
- The 10% feature is a shipping calculator that adjusts the shipping price based on the user's location and selected shipping method. 
	- The calculator uses Bing Maps Geolocation API to find the distance between two addresses 
	- It then applies a multiplier based on the selected shipping method.
- The User will choose their shipping method, enter their address, and will see their unique shipping price based on their entries upon confirmation

<!--### Roadmap of Enhancements
<!-- > _Provide a list of top-level features in the order you plan to consider them._ 
#### Sprint 1 - Back End
- Get Entire Inventory
- Get a Single Product
- Search for a Product
- Owner 
	- Create a New Product
	- Update a Product
	- Delete a Single Product

#### Sprint 2 - Front & Back End
- Browse / Search Products
- Owner 
	- Login/Logout
	- Inventory Maintenance
- Customer
	- Login/Logout
	- Manage Shopping Cart

#### Sprint 3 - Front & Back End
- Customer
	- Checkout
	- Choose a Shipping Location
	- Save Address
	- Shipping Price Calculator
- Overall Site Format / HTML / CSS Overhaul
-->
## Application Domain

This section describes the application domain.

![Domain Model](updated-domain-model.png)

As one can see, all the aspects one would expect to be in an e-store are present here. The e-store website itself can be logged into, by either a customer or an owner, and contains a record of the inventory of the store. The owner can directly manipulate the inventory, while a customer is able to search for products that are contained therein. The inventory itself is shown through products, which can be added to a shopping cart by the user. This culminates into a checkout, where the user confirms the products in their cart is the one they want to buy (they can remove products from the cart if they desire, manipulating the inventory), and proceeds to purchase them.


## Architecture and Design

This section describes the application architecture.

### Summary

The following Tiers/Layers model shows a high-level view of the web-app's architecture.

![The Tiers & Layers of the Architecture](architecture-tiers-and-layers.png)

The e-store web application, is built using the Model–View–ViewModel (VVMM) architecture pattern. 

The Model stores the application data objects including any functionality to provide persistence. 

The View is the client-side SPA built with Angular utilizing HTML, CSS and TypeScript. The ViewModel provides RESTful APIs to the client (View) as well as any logic required to manipulate the data objects from the Model.

Both the ViewModel and Model are built using Java and Spring Framework. Details of the components within these tiers are supplied below.

### Overview of User Interface

This section describes the web interface flow; this is how the user views and interacts
with the e-store application.

When first going onto the site, the user will be greeted with a login screen, asking for a username. From here, there are two possibilities -- either the user is the owner, or they are a customer.

If they are an owner, they would login with the username "admin". Upon hitting enter, they would be taken to the inventory management page. From here, the owner can see and browse through every product in their inventory. Next to every product listing is an edit button, where the details of the item can be modified. Furthermore, each product also has a delete icon, where the product will be removed from the inventory. There is also a final button on the inventory page in general, which allows new products to be added. The owner fills in the details of the product and it is then added to the inventory.

If user coming in is a customer, they can login with any username that is not "admin". Once logged in, they are taken to the browse product page, where they can simply scroll and look at products at their leisure. At the top of the page is a search bar, where products can be searched for. Next to each product is an icon to add it to the cart of the user. This cart has persistence over multiple sessions -- i.e. they can log out and then log back in, and their cart should still remain as is. Once they are done looking for products, the user can click on their cart, where they can view everything inside it, removed items as need be. Once the user is satisfied, they can click checkout, where they'll be able to "purchase" the items in question.


### View Tier
When a customer firsts opens our site they're shown a 'login' component. The login component is relatively simple and it's only role is allow the customer to enter a username, and then press a button to log in. This sends that information to the 'browser' component which either logs an existing customer in, or creates
a new account if an account with their name doesn't exist.

The browser component then displays our 'product' component, which is a list of all of the products available to purchase. The product component allows customers to add items to their cart by pressing an add button. As shown in the sequence diagram below, the customer presses an add button which calls a function to add the item to cart. That function makes the back-end HTTP PUT request to add the item to the cart.

![Add to cart diagram](addToCart-SeqDiagram.png)

After a customer has added items to their cart then can press a button in the browser component to go to the 'cart' component and review the products they have. They can remove or add products in the cart, go back to the browser, or proceed to the 'checkout' component. The checkout component is where we've implemented our 10% feature, address persistence and a shipping price calculator. We've included a sequence diagram below for our address persistence feature. In the checkout component a customer can input an address, and then when the customer is ready to checkout it makes an HTTP PUT request to store the customer address. When a customer is logging in later on we use this stored address so the customer can more easily checkout. 

![10 percent feature diagram](FULL10Percent-SeqDiagram.drawio.png)

We also have an 'admin' component for the owner to edit the site. This component is very similar to the browser component except instead of being able to add items and go to a shopping cart, the owner is able to click on products to edit their information, or click on a button to create/delete products.

### ViewModel Tier
This tier consisted of two types of classes. 

#### DAOs
The first one are DAOs, which handled persistence for the Models in the design. These classes made sure that changes performed in the View were being stored, and that the Model Tier was being changed accordingly. A diagram for the DAO classes can be seen below

![DAO UML Class Diagram](updated_dao_uml.png)

The private methods save() and load() in the DAO classes seen above were the most important part for object persistence. These methods made sure that the program could store and access Customer objects as JSON files. Another important thing to notice about the DAO classes is that each of them implements an interface of its own. This a consequence of following the Dependency injection OO principle, where in this case the interfaces act as abstractions of the actual classes. This provides looser coupling between higher-level modules and the DAO classes.

#### COntrollers
The second type of class are Controllers, which handled calls and changes performed in the View. The Controllers called functions in DAO classes so that they could handle the changes and persistence of the Model Tier. The Controllers also provided ways for the View to call it, via HTTP requests.

![Controller UML Class Diagram](updated_controller_uml.png)


### Model Tier
The Model Tier is made up of classes mimicking/modeling aspects of the e-store. This tier has to mimick primarily three things: customers, products, and customer carts (included in customer's class in this design). Classes in the Model Tier carry all important information that should be expected of the aspects being simulated. For example, it is expected that a product has things like price, name, and quantity (among other things). Therefore, all of this is carried by the Product model class, as shown in the diagram below:

![Product UML Class Diagram](updated_model_uml.png)


### Static Code Analysis/Design Improvements
![Unused code](screenshot-unused.png)

Our front-end angular code is very messy in some places and has unused imports
in areas, commented out code, and empty functions. We have 5 code smells for empty
source files, 2 for commented out code, 3 for unused imports, and 1 empty constructor.
Our code would be a lot clearer and more easily understood if these were removed. Our recommendation to
fix this is to go through our code and clean it, clearing up any imports, functions, and empty files
that we aren't using.

![Exception in code](screenshot-exception.png)

The reliability of our CustomerController class in our back-end API is rated poorly.
This is because it has two major bugs, we don’t check for a nullable variable, and
we catch an exception without handling it. These should be fixed to ensure our
code works reliably and consistently. Our recommendation is to go into CustomerController and
implement a check for any variables that may be returned null, and add code to handle
the InterruptedException.

![Logging issues](screenshot-null.png)

The way we log messages on the back-end isn’t perfect. We shouldn’t concatenate messages
inside of the logging function because according to SonarQube, it incurs a performance penalty.
We have 12 code smells for this, and it affects the majority of our log calls. We also are
missing logging for a few of our functions that were developed later on, which isn’t the best code practice.
To fix this we should add logging to any HTTP calls that don't have them, and we should preconcatenate the 
string we enter into the log functions.

## Testing
### Acceptance Testing
We have 15 user stories and 13 of them pass all of their acceptance test criteria. One of the failures fails its one acceptance test criteria. The other failure failed one of its two acceptance test criteria. All of the user stories were tested. One of the issues was when trying to create an account with a username that already exists there is no way to tell if a given username already exists because it would just log in that user with the existing name. This is only an issue because we wrote the acceptance criteria poorly. What happens is what the program is intended to do and the acceptance criteria should have been refactored.

### Unit Testing and Code Coverage
To ensure high quality software, it must be tested. There are many forms of testing, at different levels in the software. Our overall goal with unit testing is 
simple -- test every single method for what they return, a lack thereof, any modified global variables, and any errors being thrown. In general, we aim for an overall code coverage of 90% or greater, since that implies that most everything is works, sans a couple of bugs here and there. For the most recent version of the project, our coverage is as follows:

![Total Code Coverage](Estore-api-coverage.png)

As can be seen, we hit our 90% or above goal in both the instructions and branches categories.

In the following sections, we will discuss our overall coverage for each package, our design philosophy with our unit tests, and all anomalies therein.

#### ESTOREAPI
![Estoreapi package](Estore-api-estoreapi-coverage.png)

As is plain to see, the **estoreapi** package has no coverage whatsoever. Since these were provided classes and methods, we did not prioritize testing them, and instead focused our testing efforts onto code that we actually wrote. Since it did not affect our functionality, we decided that not including it for this release was alright to do.

#### MODEL
![Model Package](Estore-api-model-coverage.png)

Our philosophy when testing the **model** package was very straightforward, since these objects are what store the data of the e-store itself. As one would therefore expect, the methods implemented usually are in the realm of constructors, getters, setters, toStrings, and equals -- all of which are relatively easy to test for, and can also be tested en masse (i.e. testing the constructor and all getters simultaneously). Therefore we did not encounter many problems and were able to achieve 100% coverage.

#### Persistence
![Persistence Package](Estore-api-persistence-coverage.png)

The **persistence** package consists of all our "-DAO" files, i.e. all the files that modify our data (in the form of JSON docs) directly. Here, we have a lot more exceptions thrown, so we had to be sure they would be thrown at appropriate times. These tests can be a bit obtuse to write, so some difficultly stemmed from that, but we were alright for the most part.

##### CustomerFileDAO
![CustomerFileDAO Class](CustomerFileDAO-coverage.png)

Our only actual issue came from one method, in one class: _getCustomersArray_ in ***CustomerFileDAO***. There was basically a single case we didn't check for -- if the passed in string was null or not. 

#### CONTROLLER
![Controller Package](Estore-api-controller-coverage.png)

Finally, we have the **controller** package, which calls the methods with the **persistence** package to actually have the data manipulated when certain HTTP requests are called. A lot of our testing here follows similar principles to what is described above, with the addition that we needed to make sure the correct HTTP status was returned whenever one was indeed returned.

##### CustomerController
![CustomerController Class](CustomerController-coverage.png)

Within our ***CustomerController*** class, for the missed branches in alter and delete we simply failed to check if certain nested "if" conditions are met. For the missed intstructions the lack of testing mainly has to do with the Geolocation being a little difficult to test, we had working tests at one point but needed to add more functionally with little time left causing the tests to no longer work. However we have used to Geolocation extensivley and are confident that it works.
