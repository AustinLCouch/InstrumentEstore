package com.estore.api.estoreapi.model;

import java.util.TreeMap;
import java.util.logging.Logger;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a Customer entity.
 *
 * @author Gabriel Furtado Noll | gf7798
 * @author Hritik "Ricky" Gupta | rg4825
 */
public class Customer extends User {
    private static final Logger LOGGER = Logger.getLogger(Customer.class.getName());
    static final String STRING_FORMAT = "Customer [username=%s, cart=%s]";

    @JsonProperty("cart") private TreeMap<Integer,Integer> cart;
    @JsonProperty("state") private String state;
    @JsonProperty("city") private String city;
    @JsonProperty("street") private String street;

    public Customer(@JsonProperty("username") String username) {
        super(username);
        this.cart = new TreeMap<>();
    }

    /**
     * @return the Customer's cart
     */
    public TreeMap<Integer, Integer> getCart() {
        return cart;
    }

    /**
     * @return the Customer's State
     */
    public String getState() {
        return state;
    }

    /**
     * @return the Customer's City
     */
    public String getCity() {
        return city;
    }

    /**
     * @return the Customer's Street
     */
    public String getStreet() {
        return street;
    }

    /**
     * Changes the State the customer is located in
     * 
     * @param state new State the customer is located in
     */
    public void changeState(String state) {
        this.state = state;
    }

    /**
     * Changes the City the customer is located in
     * 
     * @param city new City the customer is located in
     */
    public void changeCity(String city) {
        this.city = city;
    }

    /**
     * Changes the Street the customer is located in
     * 
     * @param street new Street the customer is located in
     */
    public void changeStreet(String street) {
        this.street = street;
    }
    
    /**
     * @param productId id corresponding to a product in the cart.
     * 
     * @return the quantity of a given product held in the Customer's cart
     */
    public Integer prodQuantity(int productId) {
        return cart.get(productId);
    }

    /**
     * Adds Product or edits Product amount in cart. (Accepts negative quantities)
     * 
     * @param productId the id of the Product to be added/altered.
     * @param quantity the quantity to be alter for the Product. (accepts negative values)
     * 
     * @return true if successful, false otherwise (invalid quantity).
     */
    public boolean alterCart(int productId, int quantity) {
        if (quantity != 0) {
            if (cart.containsKey(productId)) {
                int oldAmount = cart.get(productId);
                quantity += oldAmount;
            }
            if (quantity > 0) {
                cart.put(productId, quantity);
                return true;
            }
            else if (quantity == 0) {
                this.deleteFromCart(productId);
                return true;
            }
        }
        return false;
    }

    /**
     * Remove every instance of a product from the cart.
     * 
     * @param productId the id of the Product to be deleted.
     * 
     * @return if the product was removed (false if product wasn't in cart)
     */
    public boolean deleteFromCart(int productId) {
        if (cart.containsKey(productId)) {
            cart.remove(productId);
            return true;
        }
        return false;
    }

    /**
     * Checks out the cart.
     */
    public void checkout() {
        cart = new TreeMap<>();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return String.format(STRING_FORMAT, username, cart.toString());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Customer) {
            return this.toString().equals(obj.toString());
        }
        return false;
    }
}
