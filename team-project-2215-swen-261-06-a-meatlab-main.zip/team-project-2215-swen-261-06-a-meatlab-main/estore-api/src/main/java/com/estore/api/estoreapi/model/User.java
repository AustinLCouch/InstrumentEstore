package com.estore.api.estoreapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a User entity.
 *
 * @author Ryan Healy | rmh1692
 */
public abstract class User {

    @JsonProperty("username") protected String username;

    public User(@JsonProperty("username") String username){
        this.username = username;    
    }

    /**
     * @return The username of the user.
     */
    public String getUsername() {
        return username;
    }    
}
