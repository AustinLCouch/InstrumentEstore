package com.estore.api.estoreapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.logging.Logger;

/**
 * Represents a Product entity.
 *
 * @author Hritik "Ricky" Gupta | rg4825
 * @author Gabriel Furtado Noll | gf7798
 */
public class Product {
    private static final Logger LOGGER = Logger.getLogger(Product.class.getName());
    static final String STRING_FORMAT = "Product [id=%d, name=%s, price=%f, quantity=%d, location=%s]";

    @JsonProperty("id") private int id;
    @JsonProperty("name") private String name;
    @JsonProperty("price") private double price;
    @JsonProperty("quantity") private int quantity;
    @JsonProperty("location") private String location;

    /**
     * Create a Product with the given id and name.
     * @param id The id of the product.
     * @param name The name of the product.
     * @param price The price of the product.
     * @param quantity The quantity of the product.
     * @param location The native locative location of the product.
     *
     * @literal @JsonProperty is used in serialization and deserialization
     * of the JSON object to the Java object in mapping the fields.  If a field
     * is not provided in the JSON object, the Java field gets the default Java
     * value, i.e. 0 for int
     */
    public Product(@JsonProperty("id") int id, @JsonProperty("name") String name, @JsonProperty("price") double price,
            @JsonProperty("quantity") int quantity, @JsonProperty("location") String location) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.location = location;
    }

    /**
     * @return The id of the product.
     */
    public int getId() {
        return id;
    }

    /**
     * @return The name of the product.
     */
    public String getName() {
        return name;
    }

    /**
     * @return The price of the product.
     */
    public double getPrice() {
        return price;
    }

    /**
     * @return The quantity of the product.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @return The name of the product.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the name of the product - necessary for JSON object to Java object deserialization.
     *
     * @param name The name of the product.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the quantity of the product
     *
     * @param quantity The quantity of the product.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return String.format(STRING_FORMAT, id, name, price, quantity, location);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Product) {
            return this.toString().equals(obj.toString());
        }
        return false;
    }
}
