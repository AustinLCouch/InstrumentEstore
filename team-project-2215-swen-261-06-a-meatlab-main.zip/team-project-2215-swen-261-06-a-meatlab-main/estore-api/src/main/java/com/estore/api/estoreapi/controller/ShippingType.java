package com.estore.api.estoreapi.controller;

import com.estore.api.estoreapi.model.Customer;

/**
 * Represents all the possible kinds of shipping types
 * that a {@linkplain Customer} can select when checking out.\
 *
 * @author Hritik "Ricky" Gupta | rg4825
 * @author Gabriel Furtado Noll | gf7798
 */
public enum ShippingType {
    REGULAR, EXPRESS, PIGEON
}
