package com.estore.api.estoreapi.persistence;

import java.io.IOException;

import com.estore.api.estoreapi.model.Customer;
import com.estore.api.estoreapi.model.Product;

/**
 * Defines the interface for Customer object persistence.
 *
 * @author Gabriel Furtado Noll | gf7798
 */
public interface CustomerDAO {
    /**
     * Creates and saves a {@linkplain Customer customer}.
     *
     * @param customer {@linkplain Customer customer} object to be created and saved.
     * <br>
     *
     * @return New {@link Customer customer} if successful, false otherwise.
     *
     * @throws IOException If there's an issue with underlying storage.
     */
    Customer register(Customer customer) throws IOException;

    /**
     * Retrieves a {@linkplain Customer customer} with the given username.
     *
     * @param username The username of the {@link Customer customer} to get
     *
     * @return  a {@link Customer customer} object with the matching username.
     *          Null if no {@link Customer customer} with a matching username is found.
     */
    Customer getCustomer(String username);

    /**
     * Updates and saves the cart owned by a {@linkplain Customer customer}.
     *
     * @param customerName The username of the {@linkplain Customer customer}.
     * @param productId Id of the {@link Product product} object to be added/changed.
     * @param quantity quantity of the {@link Product product} to be added/changed.
     *
     * @return  true if successful, false if quantity invalid, and null if
     * {@link Customer customer} could not be found.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    Boolean alterCart(String customerName, int productId, int quantity) throws IOException;

    /**
     * Deletes a product from the cart owned by a {@linkplain Customer customer} and saves it.
     *
     * @param customerName The username of the {@linkplain Customer customer}.
     * @param productId Id of the {@link Product product} object to be deleted from the cart.
     *
     * @return true if successful, false if no product found with given id, and null if
     * {@link Customer customer} could not be found.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    Boolean deleteFromCart(String customerName, int productId) throws IOException;

    /**
     * Checks out the cart owned by a {@linkplain Customer customer} and saves it.
     *
     * @param customerName The username of the {@linkplain Customer customer}.
     *
     * @return true if successful, false if {@link Customer customer} could not be found.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    boolean checkout(String customerName) throws IOException;


    /**
     * Changes the address of the {@linkplain Customer customer} and saves it.
     *
     * @param customerName The username of the {@linkplain Customer customer}.
     * @param state The new State of the {@linkplain Customer customer}.
     * @param city The new City of the {@linkplain Customer customer}.
     * @param street new Street of the {@linkplain Customer customer}.
     *
     * @return true if successful, false if {@link Customer customer} could not be found.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    boolean changeAddress(String customerName, String state, String city, String street) throws IOException;
}
