package com.estore.api.estoreapi.persistence;

import com.estore.api.estoreapi.model.Product;

import java.io.IOException;

/**
 * Defines the interface for Product object persistence.
 *
 * @author Hritik "Ricky" Gupta
 */
public interface InventoryDAO {
    /**
     * Retrieves all {@linkplain Product products}.
     *
     * @return An array of {@link Product product} objects, may be empty.
     * @throws IOException If there's an issue with underlying storage.
     */
    Product[] getInventory() throws IOException;

    /**
     * Finds all {@linkplain Product product} whose name contains the given text.
     *
     * @param containsText The text to match against.
     *
     * @return An array of {@link Product product} whose names contains the given text, may be empty.
     * @throws IOException If there's an issue with underlying storage.
     */
    Product[] findProducts(String containsText) throws IOException;

    /**
     * Retrieves a {@linkplain Product product} with the given id.
     *
     * @param id The id of the {@link Product product} to get
     *
     * @return  a {@link Product product} object with the matching id.
     *          Null if no {@link Product product} with a matching id is found.
     *
     * @throws IOException If there's an issue with underlying storage.
     */
    Product getProduct(int id) throws IOException;

    /**
     * Creates and saves a {@linkplain Product product}.
     *
     * @param product {@linkplain Product product} object to be created and saved.
     * <br>
     * The id of the product object is ignored and a new unique id is assigned.
     *
     * @return New {@link Product product} if successful, false otherwise.
     *
     * @throws IOException If there's an issue with underlying storage.
     */
    Product createProduct(Product product) throws IOException;

    /**
     * Updates and saves a {@linkplain Product product}.
     *
     * @param product {@link Product product} object to be updated and saved.
     *
     * @return Updated {@link Product product} if successful, null if
     * {@link Product product} could not be found.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    Product updateProduct(Product product) throws IOException;

    /**
     * Deletes a {@linkplain Product product} with the given id.
     *
     * @param id The id of the {@link Product product}.
     *
     * @return True if the {@link Product product} was deleted.
     * <br>
     * False if product with the given id does not exist.
     *
     * @throws IOException If underlying storage cannot be accessed.
     */
    boolean deleteProduct(int id) throws IOException;
}
