package com.estore.api.estoreapi.controller;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.estore.api.estoreapi.model.Customer;
import com.estore.api.estoreapi.model.Product;
import com.estore.api.estoreapi.persistence.CustomerDAO;
import com.estore.api.estoreapi.persistence.InventoryDAO;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * Handles the REST API requests for the Customer resource.
 * <p>
 * {@literal @}RestController Spring annotation identifies this class as a REST API
 * method handler to the Spring framework.
 *
 * @author Gabriel Furtado Noll | gf7798
 * @author Hritik "Ricky" Gupta | rg4825
 */
@RestController
@RequestMapping("users")
public class CustomerController {
    private static final Logger LOG = Logger.getLogger(CustomerController.class.getName());

    private static final double PIGEON_MULTIPLIER = 0.02;
    private static final double REGULAR_MULTIPLIER = 0.03;
    private static final double EXPRESS_MULTIPLIER = 0.04;

    private static final String DIST_CITY = "rochester";
    private static final String DIST_STATE = "ny";

    private static final String API_KEY = "ArGDuQZwkLBSUPofAdParHkieyoXOSrvEIQMvjioWyYcx7wGBgaXvSIm9tWLyYDr";
    private static final String API_URI =
            "https://dev.virtualearth.net/REST/V1/Routes/Driving?" +
            "wp.0="+ DIST_CITY + ","+ DIST_STATE +
                    "&wp.1={userAddress},{userCity},{userState}&distanceUnit=mi&key="
                    + API_KEY;

    private CustomerDAO customerDAO;
    private InventoryDAO inventoryDAO;

    /**
     * Creates a REST API controller to responds to requests.
     *
     * @param customerDAO The {@link CustomerDAO Customer Data Access Object} to perform CRUD operations.
     * <br>
     * @param inventoryDAO The {@link InventoryDAO Product Data Access Object} to perform CRUD operations.
     * <br>
     * This dependency is injected by the Spring Framework.
     */
    public CustomerController(CustomerDAO customerDAO, InventoryDAO inventoryDAO) {
        this.customerDAO = customerDAO;
        this.inventoryDAO = inventoryDAO;
    }

    /**
     * Responds to the GET request for a {@linkplain Customer customer} for the given username
     * 
     * @param customerName The username used to locate the {@link Customer customer}
     * 
     * @return ResponseEntity with {@link Customer customer} object and HTTP status of OK if found<br>
     * ResponseEntity with HTTP status of NOT_FOUND if not found<br>
     */
    @GetMapping("/{customerName}")
    public ResponseEntity<Customer> getCustomer(@PathVariable String customerName) {
        LOG.info("GET /users/" + customerName);
        Customer customer = customerDAO.getCustomer(customerName);
        if (customer != null)
            return new ResponseEntity<Customer>(customer, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Responds to the GET request for the List of {@linkplain Product products} in a 
     * {@linkplain Customer customer's} cart for the given username
     * 
     * @param customerName The username used to locate the {@link Customer customer}
     * 
     * @return ResponseEntity with array of {@link Product product} objects and HTTP status of OK if found<br>
     * ResponseEntity with HTTP status of NOT_FOUND if not found<br>
     */
    @GetMapping("/cart/{customerName}")
    public ResponseEntity<Product[]> getCart(@PathVariable String customerName) {
        try {
            LOG.info("GET /users/cart/" + customerName);
            Customer customer = customerDAO.getCustomer(customerName);
            if (customer != null) {
                TreeMap<Integer, Integer> prodMap = customer.getCart();
                Set<Integer> prodIds = prodMap.keySet();
                Product[] products = new Product[prodMap.size()];
                int x = 0;
                for (Integer i: prodIds) {
                    Product p = inventoryDAO.getProduct(i);
                    Product newp = new Product(p.getId(), p.getName(), p.getPrice(), prodMap.get(i), p.getLocation());
                    products[x] = newp;
                    ++x;
                }
                return new ResponseEntity<Product[]>(products, HttpStatus.OK);
            } 
            else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (IOException e) {
            LOG.log(Level.SEVERE,e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Registers a {@linkplain Customer customer} with the provided customer object.
     * Also creates a new cart with the Customer's username.
     *
     * @param customer - The {@link Customer customer} to register.
     *
     * @return ResponseEntity with created {@link Customer customer} object and HTTP status of CREATED.<br>
     * ResponseEntity with HTTP status of CONFLICT if {@link Customer customer} object already exists, 
     *      if username used is admin.<br>
     * ResponseEntity with HTTP status of BAD_REQUEST if {@link Customer customer} object's name is an empty string
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise.
     */
    @PostMapping("")
    public ResponseEntity<Customer> register(@RequestBody Customer customer) {
        LOG.info("POST /users " + customer);
        try {
            if (customerDAO.getCustomer(customer.getUsername()) != null ||
                    customer.getUsername().equals("admin")) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }
            if (customer.getUsername().equals("")) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            Customer newCustomer = customerDAO.register(customer);
            return new ResponseEntity<Customer>(newCustomer, HttpStatus.CREATED);

        } catch (IOException e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Alters the {@linkplain Customer customer's} cart with the {@linkplain Product product} object indicated
     * by productID, if it exists.
     * 
     * @param customerName The username of the {@link Customer customer} whose cart to update
     * @param productId The id of the {@link Product product} to be added/modified in the cart.
     * @param quantity The quantity of the {@link Product product} to be added/modified in the cart.
     * 
     * @return ResponseEntity with updated {@link Customer customer} object and HTTP status of OK if updated<br>
     * ResponseEntity with HTTP status of BAD_REQUEST if product given is not in inventory or quantity is not allowed<br>
     * ResponseEntity with HTTP status of NOT_FOUND if cart not found<br>
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise
     */
    @PutMapping("/{customerName}/{productId}/{quantity}")
    public ResponseEntity<Customer> alterCart(@PathVariable String customerName, @PathVariable int productId,
    @PathVariable int quantity) {
        LOG.info("PUT /users " + customerName + " altering product " + productId + " for quantity " + quantity);
        try {
            Customer customer = customerDAO.getCustomer(customerName);
            if (customer != null) {
                Product invProduct = inventoryDAO.getProduct(productId);
                if (invProduct != null) {
                    if (invProduct.getQuantity() >= quantity) {
                        Boolean b = customerDAO.alterCart(customerName, productId, quantity);
                        if (Boolean.TRUE.equals(b)) {
                            invProduct.setQuantity(invProduct.getQuantity() - quantity);
                            inventoryDAO.updateProduct(invProduct);
                            return new ResponseEntity<Customer>(customer, HttpStatus.OK);
                        }
                    }
                }
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IOException e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Deletes the {@linkplain Product product} from the provided cart,
     * returning all it's instances in it to the inventory.
     * 
     * @param customerName The username of the {@link Customer customer} whose cart to update
     * @param productId The id of the {@link Product product} to be deleted from the cart.
     * 
     * @return ResponseEntity with updated {@link Customer customer} object and HTTP status of OK if deleted<br>
     * ResponseEntity with HTTP status of BAD_REQUEST if {@link Product product} not found<br>
     * ResponseEntity with HTTP status of NOT_FOUND if {@link Customer customer} not found<br>
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise
     */
    @PutMapping("/{customerName}/{productId}")
    public ResponseEntity<Customer> deleteFromCart(@PathVariable String customerName, @PathVariable int productId) {
        LOG.info("PUT /carts/ " + customerName + " deleting " + productId);
        try {
            Customer customer = customerDAO.getCustomer(customerName);
            if (customer != null) {
                Product invProduct = inventoryDAO.getProduct(productId);
                if (invProduct != null) {
                    Integer quantity = customer.prodQuantity(productId);
                    Boolean b = customerDAO.deleteFromCart(customerName, productId);
                    if (Boolean.TRUE.equals(b)) {
                        invProduct.setQuantity(invProduct.getQuantity() + quantity);
                        inventoryDAO.updateProduct(invProduct);
                        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
                    }
                }
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (IOException e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Checks out all {@linkplain Product product} from the the provided {@linkplain Customer customer's}
     * cart.
     * 
     * @param customerName The username of the {@link Customer customer} whose cart to update
     * 
     * @return ResponseEntity with updated {@link Customer customer} object and HTTP status of OK if checked out<br>
     * ResponseEntity with HTTP status of NOT_FOUND if {@link Customer customer} not found<br>
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise
     */
    @PutMapping("/checkout/{customerName}")
    public ResponseEntity<Customer> checkout(@PathVariable String customerName) {
        LOG.info("PUT /checkout/ " + customerName);
        try {
            boolean b = customerDAO.checkout(customerName);
            if (b == true) {
                return new ResponseEntity<Customer>(customerDAO.getCustomer(customerName),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); 
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Responds to the GET request for the subtotal price for the cart owned by the 
     * {@linkplain Customer customer} given by the username
     * 
     * @param customerName The username used to locate the {@link Customer customer's} cart
     * 
     * @return ResponseEntity with subtotal price and HTTP status of OK if found<br>
     * ResponseEntity with HTTP status of NOT_FOUND if not found<br>
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise
     */
    @GetMapping("/subtotal/{customerName}")
    public ResponseEntity<Double> cartSubtotal(@PathVariable String customerName) {
        double subtotal = 0;
        ResponseEntity<Customer> r = getCustomer(customerName);
        if (r.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Customer c = r.getBody();
        TreeMap<Integer, Integer> cart = c.getCart();
        try {
            for (int i : cart.keySet()) {
                Product p = inventoryDAO.getProduct(i);
                Double prodPrice = p.getPrice();
                subtotal += prodPrice * cart.get(i);
            }
            return new ResponseEntity<>(Math.round(subtotal*100.0)/100.0, HttpStatus.OK);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private double calcDist(String address, String city, String state) throws IOException, InterruptedException {
        String uri = API_URI
                .replace("{userCity}", city)
                .replace("{userState}", state)
                .replace("{userAddress}", address);

        HttpClient client = HttpClient.newHttpClient();
        URI userURI = URI.create(uri);
        HttpRequest request = HttpRequest.newBuilder().uri(userURI).build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        String jsonString = response.body();

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode node = objectMapper.readTree(jsonString)
                .get("resourceSets").get(0)
                .get("resources").get(0);

        return node.get("travelDistance").asDouble();
    }

    /**
     * Responds to the GET request for the shipping price based on the distance and shipping 
     * type selected.
     * 
     * @param city The city where the {@linkplain Customer customer} is located
     * @param state The state where the {@linkplain Customer customer} is located
     * @param address The address where the {@linkplain Customer customer} is located
     * @param type The shipping type selected by the {@linkplain Customer customer}
     * 
     * @return ResponseEntity with shipping price and HTTP status of OK<br>
     * ResponseEntity with HTTP status of BAD_REQUEST if type not valid
     */
    @GetMapping("/shipping/{state}/{city}/{address}/{type}")
    public ResponseEntity<Double> shipPrice(@PathVariable String city,
                                            @PathVariable String state,
                                            @PathVariable String address,
                                            @PathVariable String type) {
        try {
            ShippingType t = ShippingType.valueOf(type);
            double distance = calcDist(address, city, state);
            double price;
            switch (t) {
                case EXPRESS:
                    price = distance * EXPRESS_MULTIPLIER;
                    break;
                case PIGEON:
                    price = distance * PIGEON_MULTIPLIER;
                    break;
                default:
                    price = distance * REGULAR_MULTIPLIER;
                    break;
            }
            return new ResponseEntity<>(Math.round(price * 100.0) / 100.0, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>((double) Integer.MAX_VALUE, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Changes the address of the {@linkplain Customer customer} with the given username
     * 
     * @param customerName The username of the {@link Customer customer} whose cart to update
     * @param state The new State of the {@linkplain Customer customer}.
     * @param city The new City of the {@linkplain Customer customer}.
     * 
     * @return ResponseEntity with updated {@link Customer customer} object and HTTP status of OK if address was changed<br>
     * ResponseEntity with HTTP status of NOT_FOUND if {@link Customer customer} not found<br>
     * ResponseEntity with HTTP status of INTERNAL_SERVER_ERROR otherwise
     */
    @PutMapping("/address/{customerName}/{state}/{city}/{street}")
    public ResponseEntity<Customer> changeAddress(@PathVariable String customerName, @PathVariable String state,
            @PathVariable String city, @PathVariable String street) {
        try {
            boolean b = customerDAO.changeAddress(customerName, state, city, street);
            if (b == false) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            Customer c = customerDAO.getCustomer(customerName);
            return new ResponseEntity<Customer>(c, HttpStatus.OK);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getLocalizedMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
