package com.estore.api.estoreapi.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * Unit testing suite for the {@link Product} class.
 *
 * @author Hritik "Ricky" Gupta | rg4825
 */
@Tag("Model-tier")
public class ProductTest {
    static int setupId = 99;
    static String setupName = "EWI";
    static double setupPrice = 299.99;
    static int setupQuantity = 2;
    static String setupLocation = "Global Village";

    static Product p;

    @BeforeEach
    public void setupProduct() {
        p = new Product(
                setupId,
                setupName,
                setupPrice,
                setupQuantity,
                setupLocation
        );
    }

    @Test
    public void testCtor() {
        assertEquals(setupId, p.getId());
        assertEquals(setupName, p.getName());
        assertEquals(setupPrice, p.getPrice());
        assertEquals(setupQuantity, p.getQuantity());
        assertEquals(setupLocation, p.getLocation());
    }

    @Test
    public void testName() {
        // setup
        String expectedName = "Bb Clarinet";

        // invoke
        p.setName(expectedName);

        // analyze
        assertEquals(expectedName, p.getName());
    }

    @Test
    public void testQuantity() {
        // setup
        int expectedQuantity = 4;

        // invoke
        p.setQuantity(expectedQuantity);;

        // analyze
        assertEquals(expectedQuantity, p.getQuantity());
    }

    @Test
    public void testToString() {
        // setup
        String expectedString = String.format(
                Product.STRING_FORMAT,
                setupId,
                setupName,
                setupPrice,
                setupQuantity,
                setupLocation
        );

        // invoke
        String actualString = p.toString();

        // analyze
        assertEquals(expectedString, actualString);
    }

    @Test
    public void testEqualsFalse() {
        //setup
        Product testpProduct = new Product(33, "test", 3.33, 10, "location");
        Customer c = new Customer("username");

        //invoke
        Boolean result = p.equals(testpProduct);
        Boolean result2 = p.equals(c);

        //analyze
        assertFalse(result);
        assertFalse(result2);
    }

}
