package com.estore.api.estoreapi.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.TreeMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * Unit testing suite for the {@link Customer} class.
 *
 * @author Gabriel Furtado Noll | gf7798
 * @author Ryan Healy | rmh1692
 */
@Tag("Model-tier")
public class CustomerTest {
    static String setupUsername = "DonaldDuck";

    static Customer c;

    @BeforeEach
    public void setupCustomer() {
        c = new Customer(setupUsername);
        c.changeState("OH");
        c.changeCity("Cleveland");
        c.changeStreet("100 Alfred Lerner Way");
    }

    @Test
    public void testCtor() {
        assertEquals(setupUsername, c.getUsername());
    }

    @Test
    public void testEqualsFalse() {
        //setup
        Customer testCustomer = new Customer("username");

        //invoke
        Boolean result = c.equals(testCustomer);
        Boolean result2 = c.equals("42");

        //analyze
        assertFalse(result);
        assertFalse(result2);
    }

    @Test
    public void testGetCart() {
        //setup
        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        testMap.put(1, 1);
        c.alterCart(1, 1);

        //invoke
        TreeMap<Integer, Integer> resultMap = c.getCart();

        //analyze
        assertEquals(resultMap, testMap);
    }

    @Test
    public void testGetState() {
        //setup
        String expected = "OH";

        //invoke
        String actual = c.getState();

        //analyze
        assertEquals(expected, actual);

    }

    @Test
    public void testGetCity() {
        //setup
        String expected = "Cleveland";

        //invoke
        String actual = c.getCity();

        //analyze
        assertEquals(expected, actual);
    }

    @Test
    public void testGetStreet() {
        //setup
        String expected = "100 Alfred Lerner Way";

        //invoke
        String actual = c.getStreet();

        //analyze
        assertEquals(expected, actual);

    }

    @Test
    public void testChangeState() {
        //setup 
        String oldString = c.getState();

        //invoke
        c.changeState("PA");

        //analyze
        assertFalse(oldString.equals(c.getState()));

    }

    @Test
    public void testChangeCity() {
        //setup 
        String oldString = c.getCity();
        
        //invoke
        c.changeCity("Pittsburgh");

        //analyze
        assertFalse(oldString.equals(c.getCity()));

    }

    @Test
    public void testChangeStreet() {
        //setup 
        String oldString = c.getStreet();
        
        //invoke
        c.changeStreet("100 Art Rooney Ave");

        //analyze
        assertFalse(oldString.equals(c.getStreet()));

    }

    @Test
    public void testAlterCartZeroQuantity() {
        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        assertEquals(false, c.alterCart(1, 0));
        assertEquals(testMap, c.getCart());
    }
    
    @Test
    public void testAlterCartAddProduct() {
        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        testMap.put(1, 3);
        assertEquals(true, c.alterCart(1, 3));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void testAlterCartTakeProduct() {
        //setup
        c.alterCart(1, 3);

        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        testMap.put(1, 1);
        assertEquals(true, c.alterCart(1, -2));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void testAlterCartRemoveProduct() {
        //setup
        c.alterCart(1, 3);

        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        assertEquals(true, c.alterCart(1, -3));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void testAlterCartInvalidRemove() {
        //setup
        c.alterCart(1, 3);

        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        testMap.put(1, 3);
        assertEquals(false, c.alterCart(1, -4));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void testProdQuantity() {
        //setup
        c.alterCart(1, 3);

        assertEquals(null, c.prodQuantity(2));
        assertEquals(3, c.prodQuantity(1));
    }
    
    @Test
    public void deleteFromCartValid() {
        //setup
        c.alterCart(1, 3);

        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        assertEquals(true, c.deleteFromCart(1));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void deleteFromCartInvalid() {
        //setup
        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        assertEquals(false, c.deleteFromCart(1));
        assertEquals(testMap, c.getCart());
    }

    @Test
    public void testCheckout() {
        //setup
        TreeMap<Integer,Integer> testMap = new TreeMap<>();
        c.alterCart(1, 3);
        c.checkout();
        TreeMap<Integer, Integer> actualMap = c.getCart();
        assertEquals(testMap, actualMap);
    }

    @Test
    public void testToString() {
        // setup
        c.alterCart(2, 2);
        c.alterCart(1, 4);
        TreeMap<Integer, Integer> testMap = new TreeMap<>();
        testMap.put(1, 4);
        testMap.put(2,2);
        String expectedString = String.format(
                Customer.STRING_FORMAT,
                setupUsername,
                testMap
        );

        // invoke
        String actualString = c.toString();

        // analyze
        assertEquals(expectedString, actualString);
    }
}
