package com.estore.api.estoreapi.controller;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.estore.api.estoreapi.model.Customer;
import com.estore.api.estoreapi.model.Product;
import com.estore.api.estoreapi.persistence.CustomerDAO;
import com.estore.api.estoreapi.persistence.InventoryDAO;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Test the CustomerController class
 * 
 * @author Gabriel Furtado Noll | gf7798
 * @author Ryan Healy | rmh1692
 */
@Tag("Controller-tier")
public class CustomerControllerTest {
    private CustomerController customerController;
    private CustomerDAO mockCustomerDAO;
    private InventoryDAO mockInventoryDAO;
    private Product[] testProducts;
    private Customer[] testCustomers;
    
    /**
     * Before each test, create a new CustomerController object and inject
     * a mock CustomerDAO and mock InventoryDAO
     */
    @BeforeEach
    public void setupCustomerController() {
        mockCustomerDAO = mock(CustomerDAO.class);
        mockInventoryDAO = mock(InventoryDAO.class);
        customerController = new CustomerController(mockCustomerDAO, mockInventoryDAO);
        testProducts = new Product[2];
        testProducts[0] = new Product(1, "Tambourine", 39.99, 4, "Alaska");
        testProducts[1] = new Product(2, "NotTambourine", 39.99, 4, "NotAlaska");
        testCustomers = new Customer[1];
        testCustomers[0] = new Customer("Scooby");
        testCustomers[0].changeState("state");
        testCustomers[0].changeCity("city");
        testCustomers[0].changeStreet("street");
        testCustomers[0].alterCart(1, 3);
    }

    @Test
    public void testGetCustomer() {
        // Setup
        Customer customer = new Customer("Scooby");
        // When the same String is passed in, our mock Customer DAO will return the Customer object
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(testCustomers[0]);

        // Invoke
        ResponseEntity<Customer> response = customerController.getCustomer(customer.getUsername());

        // Analyze
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testCustomers[0], response.getBody());
    }

    @Test
    public void testGetCustomerNotFound() {
        // Setup
        String customerName = "Doo";
        // When the above String is passed in, our mock Product DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.getCustomer(customerName);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testGetCart() throws IOException {
        // Setup
        String customerName = "Scooby";
        Product[] expected = new Product[]{new Product(1, "Tambourine", 39.99, 3, "Alaska")};
        // When the customer username is passed in, our mock Customer DAO will return the Customer object
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return the Product object
        when(mockInventoryDAO.getProduct(testProducts[0].getId())).thenReturn(testProducts[0]);

        // Invoke
        ResponseEntity<Product[]> response = customerController.getCart(customerName);

        // Analyze
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertArrayEquals(expected, response.getBody());
    }

    @Test
    public void testGetCartNotFound() throws IOException {
        // Setup
        String customerName = "Doo";
        // When the above String is passed in, our mock Customer DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(null);

        // Invoke
        ResponseEntity<Product[]> response = customerController.getCart(customerName);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testGetCartHandleException() throws IOException {
        // Setup
        String customerName = "Scooby";
        // When the customer username is passed in, our mock Customer DAO will return the Customer object
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(testCustomers[0]);
        // When getProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).getProduct(1);

        // Invoke
        ResponseEntity<Product[]> response = customerController.getCart(customerName);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }
    
    @Test
    public void testRegister() throws IOException {
        // Setup
        Customer customer = new Customer("Doo");
        // When the above Customer username is passed in, our mock Customer DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(null);
        // When the created Customer is passed in, our mock Customer DAO eill return the Customer, simulating
        // it's registration
        when(mockCustomerDAO.register(customer)).thenReturn(customer);

        // Invoke
        ResponseEntity<Customer> response = customerController.register(customer);

        // Analyze
        assertEquals(customer, response.getBody());
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testRegisterUsernameAlreadyExists() {
        // Setup
        Customer customer = new Customer("Scooby");
        // When the above Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(testCustomers[0]);

        // Invoke
        ResponseEntity<Customer> response = customerController.register(customer);

        // Analyze
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    public void testRegisterEmptyUsername() {
        // Setup
        Customer customer = new Customer("");
        // When the above Customer username is passed in, our mock Customer DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.register(customer);

        // Analyze
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testRegisterAdminUsername() {
        // Setup
        Customer customer = new Customer("admin");
        // When the above Customer username is passed in, our mock Customer DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.register(customer);

        // Analyze
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    public void testRegisterHandleException() throws IOException {
        // Setup
        Customer customer = new Customer("Doo");
        // When the above Customer username is passed in, our mock Customer DAO will return null, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(customer.getUsername())).thenReturn(null);
        // When register is called on the Mock Customer DAO, throw an IOException
        doThrow(new IOException()).when(mockCustomerDAO).register(customer);

        // Invoke
        ResponseEntity<Customer> response = customerController.register(customer);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testAlterCart() throws IOException {
        // Setup
        Customer expected = new Customer("Scooby");
        expected.alterCart(1, 4);
        int productId = 1;
        int quantity = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return the Product object
        when(mockInventoryDAO.getProduct(productId)).thenReturn(testProducts[0]);
        when(mockCustomerDAO.alterCart(testCustomers[0].getUsername(), productId, quantity)).thenAnswer(
                invocation -> {
                    return testCustomers[0].alterCart(productId, quantity);
                });

        // Invoke
        ResponseEntity<Customer> response = customerController.alterCart(testCustomers[0].getUsername(), productId,
                quantity);

        // Analyze
        assertEquals(expected, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    @Test
    public void testAlterCartInvalidProductId() throws IOException {
        // Setup
        int productId = 2;
        int quantity = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return null, simulating no product found
        when(mockInventoryDAO.getProduct(productId)).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.alterCart(testCustomers[0].getUsername(), productId,
                quantity);

        // Analyze
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testAlterCartInvalidQuantity() throws IOException {
        // Setup
        int productId = 1;
        int quantity = -7;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return the Product object
        when(mockInventoryDAO.getProduct(productId)).thenReturn(testProducts[0]);
        when(mockCustomerDAO.alterCart(testCustomers[0].getUsername(), productId, quantity)).thenAnswer(
                invocation -> {
                    return testCustomers[0].alterCart(productId, quantity);
                });

        // Invoke
        ResponseEntity<Customer> response = customerController.alterCart(testCustomers[0].getUsername(), productId,
                quantity);

        // Analyze
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testAlterCartNotFound() throws IOException {
        // Setup
        int productId = 1;
        int quantity = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.alterCart(testCustomers[0].getUsername(), productId,
                quantity);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testAlterCartHandleException() throws IOException {
        // Setup
        String customerName = "Scooby";
        int productId = 1;
        int quantity = 1;
        // When the above Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(testCustomers[0]);
        // When getProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).getProduct(1);

        // Invoke
        ResponseEntity<Customer> response = customerController.alterCart(customerName, productId, quantity);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testDeleteFromCart() throws IOException {
        // Setup
        Customer expected = new Customer("Scooby");
        int productId = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return the Product object
        when(mockInventoryDAO.getProduct(productId)).thenReturn(testProducts[0]);
        when(mockCustomerDAO.deleteFromCart(testCustomers[0].getUsername(), productId)).thenAnswer(
                invocation -> {
                    return testCustomers[0].deleteFromCart(productId);
                });

        // Invoke
        ResponseEntity<Customer> response = customerController.deleteFromCart(testCustomers[0].getUsername(),
                productId);

        // Analyze
        assertEquals(expected, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    
    @Test
    public void testDeleteFromCartInvalidProductId() throws IOException {
        // Setup
        int productId = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When the product id is passed in, our mock Inventory DAO will return null, simulating no product found
        when(mockInventoryDAO.getProduct(productId)).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.deleteFromCart(testCustomers[0].getUsername(),
                productId);

        // Analyze
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    
    @Test
    public void testDeleteFromCartNotFound() throws IOException {
        // Setup
        int productId = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // no customer found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(null);

        // Invoke
        ResponseEntity<Customer> response = customerController.deleteFromCart(testCustomers[0].getUsername(),
                productId);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }
    
    @Test
    public void testDeleteFromCartHandleException() throws IOException {
        // Setup
        int productId = 1;
        // When the Customer username is passed in, our mock Customer DAO will return the Customer object, simulating
        // a customer being found
        when(mockCustomerDAO.getCustomer(testCustomers[0].getUsername())).thenReturn(testCustomers[0]);
        // When getProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).getProduct(1);

        // Invoke
        ResponseEntity<Customer> response = customerController.deleteFromCart(testCustomers[0].getUsername(),
                productId);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testCheckout() throws IOException {
        // Setup
        String customerName = "Scooby";

        when(mockCustomerDAO.checkout(customerName)).thenReturn(true);

        // Invoke
        ResponseEntity<Customer> response = customerController.checkout(customerName);

        // Analyze
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testCheckoutNotFound() throws IOException {
        // Setup
        String customerName = "Scrapy";

        when(mockCustomerDAO.checkout(customerName)).thenReturn(false);

        // Invoke
        ResponseEntity<Customer> response = customerController.checkout(customerName);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testCheckoutHandleException() throws IOException {
        // Setup
        String customerName = "Scooby";

        doThrow(new IOException()).when(mockCustomerDAO).checkout(customerName);

        // Invoke
        ResponseEntity<Customer> response = customerController.checkout(customerName);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testChangeAddress() throws IOException {
        // Setup
        String customerName = testCustomers[0].getUsername();
        String state = "NY";
        String city = "New York City";
        String street = "A Van";
        when(mockCustomerDAO.changeAddress(customerName, state, city, street)).thenReturn(true);

        // Invoke
        ResponseEntity<Customer> response = customerController.changeAddress(customerName, state, city, street);

        // Analyze
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testChangeAddressNotFound() throws IOException {
        // Setup
        String customerName = "Scrapy";
        String state = "NY";
        String city = "New York City";
        String street = "A Van";
        when(mockCustomerDAO.changeAddress(customerName, state, city, street)).thenReturn(false);

        // Invoke
        ResponseEntity<Customer> response = customerController.changeAddress(customerName, state, city, street);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testChangeAddressHandleException() throws IOException {
        // Setup
        String customerName = "Scrapy";
        String state = "NY";
        String city = "New York City";
        String street = "A Van";
        doThrow(new IOException()).when(mockCustomerDAO).changeAddress(customerName, state, city, street);

        // Invoke
        ResponseEntity<Customer> response = customerController.changeAddress(customerName, state, city, street);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testCartSubtotal() throws IOException {
        //setup
        String customerName = testCustomers[0].getUsername();
        int id = testProducts[0].getId();
        //3 of the product where added to cart in setup
        Double expected = testProducts[0].getPrice()*3; 
        when(mockCustomerDAO.getCustomer(customerName)).thenReturn(testCustomers[0]);
        when(mockInventoryDAO.getProduct(id)).thenReturn(testProducts[0]);

        //invoke
        ResponseEntity<Double> response = customerController.cartSubtotal(customerName);

        //analyze
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expected, response.getBody());

    }

    @Test
    public void testCartSubtotalNotFound() {
        //setup
        String customerName = "Scrapy";

        //invoke
        ResponseEntity<Double> response = customerController.cartSubtotal(customerName);

        //analyze
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // @Test
    // public void testShipPrice() {
    //     //setup
    //     String state = "OH";
    //     String city = "Northfield";
    //     String address = "471 Troubadour Drive";
    //     String type = "EXPRESS";
    //     Double expected = 102.9686632;

    //     //invoke
    //     ResponseEntity<Double> response = customerController.shipPrice(city, state, address, type);

    //     //analyze
    //     assertEquals(HttpStatus.OK, response.getStatusCode());
    //     assertEquals(expected, response.getBody());

    // }

    // @Test
    // public void testShipPriceRegular() {
    //     //setup
    //     String state = "OH";
    //     String city = "Cleveland";
    //     String address = "100 Alfred Lerner Way";
    //     String type = "REGULAR";
    //     Double expected = 77.22649739999999;

    //     //invoke
    //     ResponseEntity<Double> response = customerController.shipPrice(city, state, address, type);

    //     //analyze
    //     assertEquals(HttpStatus.OK, response.getStatusCode());
    //     assertEquals(expected, response.getBody());

    // }

    // @Test
    // public void testShipPricePigeon() {
    //     //setup
    //     String state = "OH";
    //     String city = "Cleveland";
    //     String address = "100 Alfred Lerner Way";
    //     String type = "PIGEON";
    //     Double expected = 51.4843316;

    //     //invoke
    //     ResponseEntity<Double> response = customerController.shipPrice(city, state, address, type);

    //     //analyze
    //     assertEquals(HttpStatus.OK, response.getStatusCode());
    //     assertEquals(expected, response.getBody());

    // }

    @Test
    public void testShipPriceBadRequest() {
        //setup
        String state = "XD";
        String city = "LMAO";
        String address = "Jndfkasndfbasfb";
        String type = "EXPRESS";

        //invoke
        ResponseEntity<Double> response = customerController.shipPrice(city, state, address, type);

        //analyze
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }
}
