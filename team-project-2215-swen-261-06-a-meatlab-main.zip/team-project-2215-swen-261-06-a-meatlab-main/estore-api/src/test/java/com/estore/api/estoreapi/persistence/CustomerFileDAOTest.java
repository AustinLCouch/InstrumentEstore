package com.estore.api.estoreapi.persistence;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;

import com.estore.api.estoreapi.model.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.internal.matchers.Null;

/**
 * Unit testing suite for the {@link CustomerFileDAO} class.
 * 
 * @author Gabriel Furtado Noll | gf7798
 * @author Ryan Healy | rmh1692
 */
@Tag("Persistence-tier")
public class CustomerFileDAOTest {
    CustomerFileDAO customerFileDAO;
    Customer[] testCustomers;
    ObjectMapper mockObjectMapper;

    @BeforeEach
    public void setupInventoryFileDAO() throws IOException {
        mockObjectMapper = mock(ObjectMapper.class);
        testCustomers = new Customer[4];
        Customer withProd = new Customer("LordFarquad");
        withProd.changeState("Orinion");
        withProd.changeCity("Duloc City");
        withProd.changeStreet("The Castle");
        withProd.alterCart(1, 2);
        testCustomers[0] = withProd;
        testCustomers[1] = new Customer("Shrek");
        testCustomers[2] = new Customer("Donkey");
        testCustomers[3] = new Customer("Dragon");

        when(mockObjectMapper
                .readValue(new File("testFile.txt"), Customer[].class))
                .thenReturn(testCustomers);

        customerFileDAO = new CustomerFileDAO("testFile.txt", mockObjectMapper);
    }

    @Test
    public void testSaveException() throws IOException {

        doThrow(new IOException())
                .when(mockObjectMapper)
                .writeValue(any(File.class), any(Customer[].class));

        Customer newCustomer = new Customer("Fiona");

        assertThrows(IOException.class,
                () -> customerFileDAO.register(newCustomer),
                "IOException not thrown");
    }
    
    @Test
	public void testConstructorException() throws IOException {
		// this method tests the load() method through the constructor
		//ObjectMapper mockObjectMapper = mock(ObjectMapper.class);

		doThrow(new IOException())
			.when(mockObjectMapper)
				.readValue(new File("testFile.txt"), Customer[].class);

		assertThrows(IOException.class,
						() -> new CustomerFileDAO("testFile.txt", mockObjectMapper),
						"IOException not thrown");
	}

    @Test
    public void testGetCustomer() {
        // Invoke
        Customer c = customerFileDAO.getCustomer("LordFarquad");

        // Analzye
        assertEquals(c,testCustomers[0]);

    }

    @Test
    public void testGetCustomerNotFound() {
        // Invoke
        Customer c = customerFileDAO.getCustomer("Godzilla");

        // Analyze
        assertEquals(c,null);
    }
    
    @Test
    public void testRegister() {
        // Setup
        Customer c = new Customer("Fiona");

        // Invoke
        Customer result = assertDoesNotThrow(() -> customerFileDAO.register(c),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        Customer actual = customerFileDAO.getCustomer(c.getUsername());
        assertEquals(actual.getUsername(), c.getUsername());
        assertEquals(actual.getCart(), c.getCart());
    }
    
    @Test
    public void testAlterCart() {
        // Setup
        Customer c = new Customer("LordFarquad");
        c.alterCart(1, 7);

        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.alterCart("LordFarquad", 1, 5),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        assertEquals(true, result);
        assertEquals(c.getUsername(), testCustomers[0].getUsername());
        assertEquals(c.getCart(), testCustomers[0].getCart());
    }

    @Test
    public void testAlterCartInvalidQuantity() {
        // Setup
        Customer c = new Customer("LordFarquad");
        c.alterCart(1, 2);
        
        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.alterCart("LordFarquad", 1, -3),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        assertEquals(false, result);
        assertEquals(c.getUsername(), testCustomers[0].getUsername());
        assertEquals(c.getCart(), testCustomers[0].getCart());
    }

    @Test
    public void testAlterCartNotFound() {
        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.alterCart("LordFartquad", 1, 5),
                "Unexpected exception thrown");

        // Analyze
        assertNull(result);
    }

    @Test
    public void testDeleteFromCart() {
        // Setup
        Customer c = new Customer("LordFarquad");

        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.deleteFromCart("LordFarquad", 1),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        assertEquals(true, result);
        assertEquals(c.getUsername(), testCustomers[0].getUsername());
        assertEquals(c.getCart(), testCustomers[0].getCart());
    }

    @Test
    public void testDeleteFromCartInvalidId() {
        // Setup
        Customer c = new Customer("LordFarquad");
        c.alterCart(1, 2);

        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.deleteFromCart("LordFarquad", 2),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        assertEquals(false, result);
        assertEquals(c.getUsername(), testCustomers[0].getUsername());
        assertEquals(c.getCart(), testCustomers[0].getCart());
    }
    
    @Test
    public void testDeleteFromCartNotFound() {
        // Invoke 
        Boolean result = assertDoesNotThrow(() -> customerFileDAO.deleteFromCart("LordFartquad", 1),
                "Unexpected exception thrown");

        // Analyze
        assertNull(result);
    }
    
    @Test
    public void testCheckout() throws IOException {
        assertFalse(customerFileDAO.checkout("false"));
        assertTrue(customerFileDAO.checkout("Shrek"));
    }

    @Test
    public void testChangeAddress() throws IOException {
        //setup
        String state = "state";
        String city = "city";
        String street = "street";

        String oldState = testCustomers[0].getState();
        String oldCity = testCustomers[0].getCity();
        String oldStreet = testCustomers[0].getStreet();

        //invoke
        Boolean resultBoolean = customerFileDAO.changeAddress(testCustomers[0].getUsername(), state, city, street);

        //analyze
        assertTrue(resultBoolean);

        assertNotEquals(oldState, testCustomers[0].getState());
        assertEquals(state, testCustomers[0].getState());

        assertNotEquals(oldCity, testCustomers[0].getCity());
        assertEquals(city, testCustomers[0].getCity());

        assertNotEquals(oldStreet, testCustomers[0].getStreet());
        assertEquals(street, testCustomers[0].getStreet());

    }

    @Test
    public void testChangeAddressInvalid() throws IOException {
        //setup
        String customerName = "Harold";
        String state = "state";
        String city = "city";
        String street = "street";

        //invoke
        Boolean resultBoolean = customerFileDAO.changeAddress(customerName, state, city, street);

        //analyze
        assertFalse(resultBoolean);
    }
}
