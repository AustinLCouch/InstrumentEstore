package com.estore.api.estoreapi.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.estore.api.estoreapi.persistence.InventoryDAO;
import com.estore.api.estoreapi.model.Product;

import org.apache.tomcat.websocket.pojo.PojoEndpointBase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Test the Inventory Controller class
 * 
 * @author Ryan Healy
 * @author Gregory Ojiem
 */
@Tag("Controller-tier")
public class InventoryControllerTest {

    private InventoryController inventoryController;
    private InventoryDAO mockInventoryDAO;
    private Product[] testProducts;

    /**
     * Before each test, create a new InventoryController object and inject
     * a mock Inventory DAO
     */
    @BeforeEach
    public void setupInventoryController() {
        mockInventoryDAO = mock(InventoryDAO.class);
        inventoryController = new InventoryController(mockInventoryDAO);
        testProducts = new Product[1];
        testProducts[0] = new Product(12, "Tambourine", 39.99, 2, "Alaska");
    }

    @Test
    public void testGetProduct() throws IOException {  // getProduct may throw IOException
        // Setup
        Product product = new Product(12, "Tambourine", 39.99, 2, "Alaska");
        // When the same id is passed in, our mock Inventory DAO will return the Product object
        when(mockInventoryDAO.getProduct(product.getId())).thenReturn(product);

        // Invoke
        ResponseEntity<Product> response = inventoryController.getProduct(product.getId());

        // Analyze
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(product,response.getBody());
    }

    @Test
    public void testGetProductNotFound() throws Exception { // createProduct may throw IOException
        // Setup
        int productID = 99;
        // When the same id is passed in, our mock Product DAO will return null, simulating
        // no product found
        when(mockInventoryDAO.getProduct(productID)).thenReturn(null);

        // Invoke
        ResponseEntity<Product> response = inventoryController.getProduct(productID);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND,response.getStatusCode());
    }

    @Test
    public void testGetProductHandleException() throws Exception { // createProduct may throw IOException
        // Setup
        int productID = 99;
        // When getProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).getProduct(productID);

        // Invoke
        ResponseEntity<Product> response = inventoryController.getProduct(productID);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }
    
    @Test
    public void testCreateProductNoneFound() throws IOException { // findProducts returns an empty list
        // Setting up objects
        Product product = new Product(12, "Tambourine", 39.99, 2, "Alaska");

        // When we pass in an identical product ID, mockInventoryDAO returns the Product object
        when(mockInventoryDAO.findProducts("Tambourine")).thenReturn(new Product[0]);
        when(mockInventoryDAO.createProduct(product)).thenReturn(product);
    
        // Invoking
        ResponseEntity<Product> response = inventoryController.createProduct(product);

        // Analyze
        assertEquals(HttpStatus.CREATED,response.getStatusCode());
        assertEquals(product,response.getBody());
    }

    @Test
    public void testCreateProductSomeFound() throws IOException { // findProducts returns a non-empty
        // Setting up objects
        Product product = new Product(12, "Bongos", 49.99, 3, "Texas");
        
        // When we pass in an identical product ID, mockInventoryDAO returns the Product object
        when(mockInventoryDAO.findProducts("Bongos")).thenReturn(testProducts);
        when(mockInventoryDAO.createProduct(product)).thenReturn(product);
    
        // Invoking
        ResponseEntity<Product> response = inventoryController.createProduct(product);

        // Analyze
        assertEquals(HttpStatus.CREATED,response.getStatusCode());
        assertEquals(product,response.getBody());
    }

    @Test
    public void testCreateProductFailureCases() throws IOException { // createProduct may throw IOException
        // Setting up objects
        Product testProductOne = new Product(12, "Drums", 39.99, 2, "Antarctica"); //This case is if the ID is identical, should FAIL
        Product testProductTwo = new Product(13, "Tambourine", 39.99, 2, "Alaska"); //This case is if product name and location are identical, should FAIL 
        Product testProductThree = new Product(13, "Tambourine", 39.99, 2, "Georgia"); //This case is where only location is different, this should PASS
        Product testProductFour = new Product(13, "Flute", 39.99, 2, "Alaska"); //This case is where only name is different, this should PASS

        // When we pass in an identical product ID, mockInventoryDAO returns the Product object
        when(mockInventoryDAO.getProduct(12)).thenReturn(testProducts[0]);
        when(mockInventoryDAO.findProducts("Tambourine")).thenReturn(testProducts);
        when(mockInventoryDAO.findProducts("Flute")).thenReturn(testProducts);

        // Invoking
        ResponseEntity<Product> response = inventoryController.createProduct(testProductOne);
        ResponseEntity<Product> response2 = inventoryController.createProduct(testProductTwo);
        ResponseEntity<Product> response3 = inventoryController.createProduct(testProductThree);
        ResponseEntity<Product> response4 = inventoryController.createProduct(testProductFour);

        // Analyze
        assertEquals(HttpStatus.CONFLICT,response.getStatusCode());
        assertEquals(HttpStatus.CONFLICT,response2.getStatusCode());
        assertEquals(HttpStatus.CREATED,response3.getStatusCode());
        assertEquals(HttpStatus.CREATED,response4.getStatusCode());
    }

    @Test
    public void testCreateProductHandleException() throws IOException {  // createProduct may throw IOException
        // Setup
        Product product = new Product(12, "Tambourine", 39.99, 2, "Alaska");

        // When createProduct is called on the Mock Inventory DAO, throw an IOException
        when(mockInventoryDAO.findProducts("Tambourine")).thenReturn(new Product[0]);
        doThrow(new IOException()).when(mockInventoryDAO).createProduct(product);

        // Invoke
        ResponseEntity<Product> response = inventoryController.createProduct(product);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testDeleteProduct() throws IOException { // deleteProduct may throw IOException
        // Setup
        int productID = 99;
        // when deleteProduct is called return true, simulating successful deletion
        when(mockInventoryDAO.deleteProduct(productID)).thenReturn(true);

        // Invoke
        ResponseEntity<Product> response = inventoryController.deleteProduct(productID);

        // Analyze
        assertEquals(HttpStatus.OK,response.getStatusCode());
    }

    @Test
    public void testDeleteProductNotFound() throws IOException { // deleteProduct may throw IOException
        // Setup
        int productID = 99;
        // when deleteProduct is called return false, simulating failed deletion
        when(mockInventoryDAO.deleteProduct(productID)).thenReturn(false);

        // Invoke
        ResponseEntity<Product> response = inventoryController.deleteProduct(productID);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND,response.getStatusCode());
    }

    @Test
    public void testDeleteProductHandleException() throws IOException { // deleteProduct may throw IOException
        // Setup
        int productID = 99;
        // When deleteProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).deleteProduct(productID);

        // Invoke
        ResponseEntity<Product> response = inventoryController.deleteProduct(productID);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testGetInventory() throws IOException { // getHeroes may throw IOException
        // Setup
        Product[] products = new Product[2];
        products[0] = new Product(50, "Green Horn", 8.99, 10, "Greenland");
        products[1] = new Product(60, "Red Horn", 9.99, 20, "Redland");
        // When getInventory is called return the products created above
        when(mockInventoryDAO.getInventory()).thenReturn(products);

        // Invoke
        ResponseEntity<Product[]> response = inventoryController.getInventory();

        // Analyze
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(products,response.getBody());
    }

    @Test
    public void testGetHeroesHandleException() throws IOException { // getHeroes may throw IOException
        // Setup
        // When getInventory is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).getInventory();

        // Invoke
        ResponseEntity<Product[]> response = inventoryController.getInventory();

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testSearchHeroes() throws IOException { // findHeroes may throw IOException
        // Setup
        String searchString = "re";
        Product[] products = new Product[2];
        products[0] = new Product(50, "Green Horn", 8.99, 10, "Greenland");
        products[1] = new Product(60, "Red Horn", 9.99, 20, "Redland");
        // When findProducts is called with the search string, return the two
        /// products above
        when(mockInventoryDAO.findProducts(searchString)).thenReturn(products);

        // Invoke
        ResponseEntity<Product[]> response = inventoryController.searchProducts(searchString);

        // Analyze
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(products,response.getBody());
    }

    @Test
    public void testSearchHeroesHandleException() throws IOException { // findHeroes may throw IOException
        // Setup
        String searchString = "an";
        // When createProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).findProducts(searchString);

        // Invoke
        ResponseEntity<Product[]> response = inventoryController.searchProducts(searchString);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }

    @Test
    public void testUpdateHero() throws IOException { // updateHero may throw IOException
        // Setup
        Product product = new Product(60, "Red Horn", 9.99, 20, "Redland");
        // when updateProduct is called, return true simulating successful
        // update and save
        when(mockInventoryDAO.updateProduct(product)).thenReturn(product);
        ResponseEntity<Product> response = inventoryController.updateProduct(product);
        product.setName("Green Horn");

        // Invoke
        response = inventoryController.updateProduct(product);

        // Analyze
        assertEquals(HttpStatus.OK,response.getStatusCode());
        assertEquals(product,response.getBody());
    }

    @Test
    public void testUpdateHeroFailed() throws IOException { // updateHero may throw IOException
        // Setup
        Product product = new Product(60, "Red Horn", 9.99, 20, "Redland");
        // when updateProduct is called, return true simulating successful
        // update and save
        when(mockInventoryDAO.updateProduct(product)).thenReturn(null);

        // Invoke
        ResponseEntity<Product> response = inventoryController.updateProduct(product);

        // Analyze
        assertEquals(HttpStatus.NOT_FOUND,response.getStatusCode());
    }

    @Test
    public void testUpdateHeroHandleException() throws IOException { // updateHero may throw IOException
        // Setup
        Product product = new Product(60, "Red Horn", 9.99, 20, "Redland");
        // When updateProduct is called on the Mock Inventory DAO, throw an IOException
        doThrow(new IOException()).when(mockInventoryDAO).updateProduct(product);

        // Invoke
        ResponseEntity<Product> response = inventoryController.updateProduct(product);

        // Analyze
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
    }
    
}
