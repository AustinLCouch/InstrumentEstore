package com.estore.api.estoreapi.persistence;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.estore.api.estoreapi.model.Product;

/**
 * Unit testing suite for the {@link InventoryFileDAO} class.
 * 
 * @author Ryan Healy | rmh1692
 * @author Gabriel Furtado Noll | gf7798
 * @author Austin Couch | alc9026
 */
@Tag("Persistence-tier")
public class InventoryFileDAOTest{
	InventoryFileDAO inventoryFileDAO;
	Product[] testInventory;
	ObjectMapper mockObjectMapper;

	@BeforeEach
    public void setupInventoryFileDAO() throws IOException{
        mockObjectMapper = mock(ObjectMapper.class);
        testInventory = new Product[4];
        testInventory[0] = new Product(0, "testFlute", 2, 2, "testLocation");
        testInventory[1] = new Product(1, "testGuitar", 9, 4, "testLocation");
        testInventory[2] = new Product(2, "testDrums", 10, 6, "testLocation");
        testInventory[3] = new Product(3, "testDrums2", 12, 3, "testLocation");

        when(mockObjectMapper
                .readValue(new File("testFile.txt"), Product[].class))
                        .thenReturn(testInventory);

        inventoryFileDAO = new InventoryFileDAO("testFile.txt", mockObjectMapper);
    }

	@Test
	public void testGetProductsArrayAll(){
		assertArrayEquals(testInventory, inventoryFileDAO.getInventory(), "GetInventory did not return all products");
	}

	@Test
	public void testGetProductsArrayFind() throws IOException{
		Product[] foundProducts = {testInventory[2], testInventory[3]};
		assertArrayEquals(foundProducts, inventoryFileDAO.findProducts("testD"), "FindProducts did not return all products whose name includes the search term");
	}

	@Test
	public void testSaveException() throws IOException{

		doThrow(new IOException())
			.when(mockObjectMapper)
				.writeValue(any(File.class), any(Product[].class));


		Product newProduct = new Product(102, "NewName", 10, 10, "A new Place");
		
		assertThrows(IOException.class,
						() -> inventoryFileDAO.createProduct(newProduct),
						"IOException not thrown");
	}

	@Test
	public void testConstructorException() throws IOException {
		// this method tests the load() method through the constructor
		//ObjectMapper mockObjectMapper = mock(ObjectMapper.class);

		doThrow(new IOException())
			.when(mockObjectMapper)
				.readValue(new File("testFile.txt"), Product[].class);

		assertThrows(IOException.class,
						() -> new InventoryFileDAO("testFile.txt", mockObjectMapper),
						"IOException not thrown");
	}

    @Test
    public void testNextId() throws IOException {
        //Setup and Invoke
        Product product1 = inventoryFileDAO.createProduct(testInventory[0]);
        Product product2 = inventoryFileDAO.createProduct(testInventory[1]);
        int expectedId = product1.getId() + 1;
        int testId = product2.getId();
        //Analyze
        assertEquals(expectedId, testId);      
    }

    @Test
    public void testFindProducts() {
        // Invoke
        Product[] products = inventoryFileDAO.findProducts("um");

        // Analyze
        assertEquals(products.length,2);
        assertEquals(products[0],testInventory[2]);
        assertEquals(products[1],testInventory[3]);
    }

    @Test
    public void testGetProduct() {
        // Invoke
        Product p = inventoryFileDAO.getProduct(0);

        // Analzye
        assertEquals(p,testInventory[0]);
    }

    @Test
    public void testGetProductNotFound() {
        // Invoke
        Product p = inventoryFileDAO.getProduct(98);

        // Analyze
        assertEquals(p,null);
    }
    
    @Test
    public void testCreateProduct() {
        // Setup
        Product p = new Product(4, "NotAnInsrument", 100, 50, "NotALocation");

        // Invoke
        Product result = assertDoesNotThrow(() -> inventoryFileDAO.createProduct(p),
                                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        Product actual = inventoryFileDAO.getProduct(p.getId());
        assertEquals(actual.getId(),p.getId());
        assertEquals(actual.getName(),p.getName());
    }
    
    @Test
    public void testUpdateProduct() {
        // Setup
        Product p = new Product(1, "NotAnInsrument", 100, 50, "NotALocation");

        // Invoke
        Product result = assertDoesNotThrow(() -> inventoryFileDAO.updateProduct(p),
                "Unexpected exception thrown");

        // Analyze
        assertNotNull(result);
        Product actual = inventoryFileDAO.getProduct(p.getId());
        assertEquals(actual, p);
    }
    
    @Test
    public void testUpdateProductNotFound() {
        // Setup
        Product p = new Product(99, "NotAnInsrument", 100, 50, "NotALocation");

        // Invoke
        Product result = assertDoesNotThrow(() -> inventoryFileDAO.updateProduct(p),
                                                "Unexpected exception thrown");

        // Analyze
        assertNull(result);
    }
    
    @Test
    public void testDeleteProduct() {
        // Invoke
        boolean result = assertDoesNotThrow(() -> inventoryFileDAO.deleteProduct(1),
                "Unexpected exception thrown");

        // Analzye
        assertEquals(result, true);
        // We check the internal tree map size against the length
        // of the test products array - 1 (because of the delete)
        // Because products attribute of InventoryFileDAO is package private
        // we can access it directly
        assertEquals(inventoryFileDAO.products.size(), testInventory.length - 1);
    }
    
    @Test
    public void testDeleteProductNotFound() {
        // Invoke
        boolean result = assertDoesNotThrow(() -> inventoryFileDAO.deleteProduct(98),
                                                "Unexpected exception thrown");

        // Analyze
        assertEquals(result,false);
        assertEquals(inventoryFileDAO.products.size(),testInventory.length);
    }
}
