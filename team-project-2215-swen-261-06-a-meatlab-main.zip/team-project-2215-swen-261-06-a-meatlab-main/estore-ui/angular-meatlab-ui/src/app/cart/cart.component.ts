import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { Product } from '../product';
import { CustomerService } from '../customer.service';
import { InfoService } from '../info.service';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  usernameInfo = "default";
  productCart: Product[] = [];
  totalMoney: number = 0;
  
  constructor(private router : Router, private customerService : CustomerService, private productService : ProductService, private infoService : InfoService) { }

  ngOnInit(): void {
    this.getCartInfo();
  }

  goToBrowser(): void {
    this.router.navigate(['/', 'browser']);
  }

  goToCheckout(): void {
    this.router.navigate(['/', 'checkout']);
  }

displayMessage(length : number) {
    var list = document.getElementsByClassName('productCart')[0];
    var message = document.getElementById('message');
    var hello = "Hi " + this.usernameInfo;

    if (message != null && list != null) {
      if (length != 0) {
        message.innerHTML = hello + "! The products in your cart are:";
        list.setAttribute("style", "display:block");
      } else {
        message.innerHTML = hello + "! Your cart is empty, go back to the browser to add products.";
        list.setAttribute("style", "display:none");
      }
    }
  }

  getCartInfo(): void {
    this.usernameInfo = this.infoService.getStringUsername();
    this.customerService.getCart(this.usernameInfo).subscribe(productCart => {
      this.productCart = productCart;
      this.displayMessage(productCart.length);
    });
    this.customerService.subtotalPrice(this.usernameInfo).subscribe(totalMoney => this.totalMoney = totalMoney);
  }

  removeFromCart(id : number): void {
    this.customerService.removeFromCustomerCart(this.infoService.getStringUsername(), id).subscribe(blank => {
      this.getCartInfo();
    });
  }

  removeAllFromCart(id : number, quantity : number): void {
    this.customerService.removeAllFromCustomerCart(this.infoService.getStringUsername(), id, -1*quantity).subscribe(blank => {
      this.getCartInfo();
    });
  }
}