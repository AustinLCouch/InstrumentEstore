import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { InfoService } from '../info.service';

@Component({
  selector: 'app-browser',
  templateUrl: './browser.component.html',
  styleUrls: ['./browser.component.css']
})

export class BrowserComponent implements OnInit {
  customerInfo: Customer = {username: "admin", cart: [], city: "", state: "", street: ""}
  username = "AllGoodNamesRGone"

  constructor(private router : Router, private customerService : CustomerService, private infoService : InfoService) {
  }

  ngOnInit(): void {
    this.getCustomer()
  }

  getCustomer(): void {
    this.username = this.infoService.getStringUsername()
    this.customerService.getCustomer(this.username).subscribe(customerInfo => this.customerInfo = customerInfo)
    if (this.customerInfo.username == "admin") {
      this.customerService.createCustomer(this.username).subscribe(customerInfo => this.customerInfo = customerInfo)
    }
  }

  goToCart(): void {
    this.router.navigate(['/', 'cart'])
  }

  goToLogin(): void {
    this.router.navigate(['/', 'login'])
  }
}
