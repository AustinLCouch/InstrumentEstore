import { Injectable } from '@angular/core';
import { Product } from './product';
import { Customer } from './customer';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class CustomerService {
  private customerURL = 'http://localhost:8080/users';

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) { }

  getCart(username : string): Observable<Product[]> {
    return this.http.get<Product[]>(this.customerURL+"/cart/"+username)
  } 
  
  getCustomer(username : string): Observable<Customer> {
    return this.http.get<Customer>(this.customerURL+"/"+username) 
  }

  createCustomer(usernameInfo : string): Observable<Customer> {
    const info : string = "{\"username\":\"" + usernameInfo + "\"}"
    return this.http.post<Customer>(this.customerURL, info, this.httpOptions)
  } 

  addToCustomerCart(username : string, id : number): Observable<Customer> {
    return this.http.put<Customer>(this.customerURL+"/"+username+"/"+id+"/1", this.httpOptions)
  }

  removeFromCustomerCart(username : string, id : number): Observable<Customer> {
    return this.http.put<Customer>(this.customerURL+"/"+username+"/"+id+"/-1", this.httpOptions)
  }

  removeAllFromCustomerCart(username : string, id : number, quantity : number): Observable<Customer> {
    return this.http.put<Customer>(this.customerURL+"/"+username+"/"+id+"/"+quantity.toString(), this.httpOptions)
  }

  subtotalPrice(username : string) {
    return this.http.get<number>(this.customerURL+"/subtotal/"+username, this.httpOptions)
  }

  shippingPrice(state : string, city : string, address : string, type : string): Observable<number> {
    return this.http.get<number>(this.customerURL+"/shipping/"+state+"/"+city+"/"+address+"/"+type, this.httpOptions)
  }

  checkoutCart(username : string): Observable<Customer> {
    return this.http.put<Customer>(this.customerURL+"/checkout/"+username, this.httpOptions)
  }

  storeAddress(state: string, city: string, address: string, username: string): Observable<Customer> {
    "/address/{customerName}/{state}/{city}/{street}"
    return this.http.put<Customer>(this.customerURL+"/address/"+username+"/"+state+"/"+city+"/"+address, this.httpOptions)
  }
}
