import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InfoService {
  private username = "default"

  constructor() { }

  public getStringUsername(): string {
    return this.username
  }

  public updateUsername(username : string): void {
    this.username = username
  }  
}
