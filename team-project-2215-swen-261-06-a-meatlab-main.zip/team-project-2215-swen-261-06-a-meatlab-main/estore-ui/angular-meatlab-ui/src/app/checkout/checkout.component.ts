import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { InfoService } from '../info.service';
import { Product } from '../product';
import { Customer } from '../customer';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  username = "default";
  productCart: Product[] = [];
  subtotalPrice: number = 0;
  shippingPrice: number = 0;
  finalTotal: number = 0;
  customerInfo: Customer = {username: "admin", cart: [], city: "test", state: "", street: ""}
  
  constructor(private router : Router, private customerService : CustomerService, private infoService : InfoService) { }

  ngOnInit(): void {
    this.getInfoForCheckout();
    (document.getElementById("checkout") as HTMLButtonElement).onsubmit = function() {return false};
  }

  goToCart(): void {
    this.router.navigate(['/', 'cart']);
  }

  setAddress(streetString : string, cityString : string, stateString : string): void {
    if (streetString != null || cityString != null || stateString != null) {
      var address = document.getElementById("address") as HTMLInputElement;
      var city = document.getElementById('city') as HTMLInputElement;
      var state = document.getElementById('state') as HTMLInputElement;
      if (address != null && state != null && city != null) {
        address.setAttribute("value", streetString);
        city.setAttribute("value", cityString);
        state.setAttribute("value", stateString);
      }
    }
  }

  getInfoForCheckout(): void {
    this.username = this.infoService.getStringUsername();
    this.customerService.getCustomer(this.username).subscribe(customer => {
      this.setAddress(customer.street, customer.city, customer.state);
    })
    this.customerService.getCart(this.username).subscribe(productCart => this.productCart = productCart);
    for (var product of this.productCart) {
      product.price = product.quantity * product.price;
    }
  }

  finalizeCheckout(state : string, city : string, address : string): void {
    this.customerService.storeAddress(state, city, address, this.username).subscribe(customerInfo => {
      this.customerInfo = this.customerInfo
    });
    for (var product of this.productCart) {
      product.price = product.quantity * product.price;
    }
    var checkoutOption = (document.getElementById("delivery") as HTMLSelectElement).value;
    var options = document.getElementsByClassName('options')[0];
    var payment = document.getElementsByClassName('payment')[0];
    var nullAddress = document.getElementById('error-null-address')

    this.customerService.subtotalPrice(this.username).subscribe(subtotalPrice => {
      this.subtotalPrice = subtotalPrice
      this.customerService.shippingPrice(state, city, address.replace(/\s/g, ""), checkoutOption).subscribe(shippingPrice => {
        if (shippingPrice > 2147483646) {
          if (nullAddress != null) {
            nullAddress.innerHTML = "Address not found!!! Try entering a different address."
          }
        }
        this.shippingPrice = shippingPrice
        this.finalTotal = subtotalPrice + shippingPrice
        options.setAttribute("style", "display:none");
        payment.setAttribute("style", "display:inline-block");
      });
    });
  }
  
  finalizePayment(): void {
    this.customerService.checkoutCart(this.username).subscribe();
    this.router.navigate(['/', 'browser']);
  }
}
