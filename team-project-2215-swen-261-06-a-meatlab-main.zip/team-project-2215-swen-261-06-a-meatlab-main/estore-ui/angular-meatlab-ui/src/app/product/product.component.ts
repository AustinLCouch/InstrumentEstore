import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { CustomerService } from '../customer.service';
import { InfoService } from '../info.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

	products: Product[] = [];
  searchString: string = ""

  constructor(private productService: ProductService, private customerService : CustomerService, private infoService : InfoService) { }

  ngOnInit(): void {
    this.getAllProducts();
    (document.getElementById("search") as HTMLButtonElement).onsubmit = function() {return false};
  }

  displayMessage(len : number, name : string): void {
    var message = document.getElementById("none-message");
    if (message != null) {
      if (len == 0 && name == "$$$") {
        message.innerHTML = "Please enter a valid product name."
      } else if (len == 0) {
        message.innerHTML = "No products found. Try entering a valid product name, or viewing all products."
      } else {
        message.innerHTML = ""
      }
    }
  }

  getProducts(productName : string): void {
    if (productName == "") {
      productName = "$$$";
    }
    this.productService.searchProducts(productName)
    .subscribe(products => {
      this.products = products;
      this.displayMessage(products.length, productName);
    });
    this.searchString = productName
  }

  getAllProducts(): void {
    this.productService.searchProducts("")
    .subscribe(products => {
      this.products = products;
      this.displayMessage(products.length, "");
    });
    this.searchString = ".$$";
  }

  addToCart(id : number): void {
    this.customerService.addToCustomerCart(this.infoService.getStringUsername(), id).subscribe(blank => {
      this.getProducts(this.searchString)
    });
  }
  
}