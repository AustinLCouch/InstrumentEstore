import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {

  products: Product[] = [];
  searchName: string = "";
  defaultProduct: Product = {id: 0, name: "", price: 0, quantity: 0, location: ""}
  productToEdit: Product;
  updatingProduct: boolean = false;

  constructor(private router : Router, private productService: ProductService) {
    this.productToEdit = this.defaultProduct;
  }

  ngOnInit(): void {
    this.getAllProducts();
  }

  displayMessage(len : number, name : string): void {
    var message = document.getElementById("none-message");
    if (message != null) {
      if (len == 0 && name == "$$$") {
        message.innerHTML = "Please enter a valid product name."
      } else if (len == 0) {
        message.innerHTML = "No products found. Try entering a valid product name, or viewing all products."
      } else {
        message.innerHTML = ""
      }
    }
  }

  getProducts(productName : string): void {
    if (productName == "") {
      productName = "$$$";
    }
    this.productService.searchProducts(productName)
    .subscribe(products => {
      this.products = products;
      this.displayMessage(products.length, productName);
    });
    this.searchName = productName
  }
  
  getAllProducts(): void {
    this.productService.searchProducts("")
    .subscribe(products => {
      this.products = products;
      this.displayMessage(products.length, "");
    });
    this.searchName = ".$$";
  }

  updateProducts(productName : string): void {
    this.getProducts(productName); //bad code, delete this when I figure out a proper fix
  }

  hideEditor() {
    var editor = document.getElementsByClassName('editor')[0];
    editor.setAttribute("style", "display:none");
  }

  displayEditor() {
    var editor = document.getElementsByClassName('editor')[0];
    editor.setAttribute("style", "display:inline-block");
  }

  createProductInit() {
    var createButton = document.getElementById('createButton') as HTMLButtonElement;
    createButton.textContent = "Create a new product";
    this.productToEdit = this.defaultProduct;
    this.displayEditor();
  }

  createProduct(product : Product) {
    this.productService.createProduct(product).subscribe(blank => {
      this.hideEditor();
      this.updateProducts(this.searchName);
    });
  }
  
  updateProduct(product : Product) {
    this.productService.updateProduct(product).subscribe(blank => {
      this.updatingProduct = false;
      this.hideEditor();
      this.updateProducts(this.searchName);
    });
  }

  editProduct(product : Product): void {
    var createButton = document.getElementById('createButton') as HTMLButtonElement;
    createButton.textContent = "Create a new product instead";
    this.productToEdit = product;
    this.updatingProduct = true;
    var editor = document.getElementsByClassName('editor')[0];
    editor.setAttribute("style", "display:inline-block"); //normally the product editor portion is hidden, this line of code 'unhides' it
  }

  deleteProduct(id : number) {
    this.productService.deleteProduct(id).subscribe(blank => {
      this.updateProducts(this.searchName);
    });
  }

  confirm(idInfo : number, nameInfo : string, priceInfo : string, quantityInfo : string, locationInfo : string) {
    const idInfoNum = idInfo;
    const priceInfoNum = parseInt(priceInfo);
    const quantityInfoNum = parseInt(quantityInfo);
    const newProduct: Product = {
      id: idInfoNum,
      name: nameInfo,
      price: priceInfoNum,
      quantity: quantityInfoNum,
      location: locationInfo
    }

    var inputName = document.getElementsByClassName('nameInfo')[0];
    var inputPrice = document.getElementsByClassName('priceInfo')[0];
    var inputQuantity = document.getElementsByClassName('quantityInfo')[0];
    var inputLocation = document.getElementsByClassName('locationInfo')[0];

    if (this.updatingProduct) {
      if (inputName != null && inputPrice != null && inputQuantity != null && inputLocation != null) {
        inputName.setAttribute("value", nameInfo.toString());
        inputPrice.setAttribute("value", priceInfo);
        inputQuantity.setAttribute("value", quantityInfo);
        inputLocation.setAttribute("value", locationInfo);
      }
      this.updateProduct(newProduct);
    } else {
      if (inputName != null && inputPrice != null && inputQuantity != null && inputLocation != null) {
        inputName.setAttribute("value", "");
        inputPrice.setAttribute("value", "");
        inputQuantity.setAttribute("value", "");
        inputLocation.setAttribute("value", "");
      }
      this.createProduct(newProduct);
    }
  }

  goToLogin(): void {
    this.router.navigate(['/', 'login']);
  }
}
