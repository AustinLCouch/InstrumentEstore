import { Injectable } from '@angular/core';
import { Product } from './product';
import { catchError, Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ProductService {
  private productURL = 'http://localhost:8080/inventory';

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.productURL)
  }

  getProduct(id : string): Observable<Product> {
    return this.http.get<Product>(this.productURL+"/"+id)
  }

  searchProducts(productName : string): Observable<Product[]> {
    if (productName == ".$$") {
      productName = "";
    }
    return this.http.get<Product[]>(this.productURL+"/?name="+productName)
  }

  createProduct(product : Product): Observable<Product> {
    return this.http.post<Product>(this.productURL, JSON.stringify(product), this.httpOptions) //add error handling later
  }

  updateProduct(product : Product): Observable<Product> {
    return this.http.put<Product>(this.productURL, JSON.stringify(product), this.httpOptions)
  }

  deleteProduct(id : number): Observable<unknown> {
    return this.http.delete(this.productURL+"/"+id.toString(), this.httpOptions)
  }
}
