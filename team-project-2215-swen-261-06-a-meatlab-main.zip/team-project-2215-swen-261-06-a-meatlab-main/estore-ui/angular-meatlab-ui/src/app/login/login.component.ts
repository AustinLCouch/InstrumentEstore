import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { InfoService } from '../info.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  constructor(private router : Router, private infoService : InfoService) {
  }

  ngOnInit(): void { }

  storeLogin(username : string): void {
    if (username == "admin") {
      this.router.navigate(['/', 'admin'])
    } else if (username == "") {
      var text = document.getElementsByClassName('inputText')[0]; //add error message later
    } else {
      this.router.navigate(['/', 'browser'])
      this.infoService.updateUsername(username)
    }
  }
}
