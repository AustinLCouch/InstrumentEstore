# E-Store:  Meatlab -- Musical Instruments

An online E-store system built in Java 8=>15 and Angular JS.
  
## Team
- Gabriel Furtado Noll
- Hritik "Ricky" Gupta
- Austin Couch
- Ryan Healy
- Gregory Ojiem

## Prerequisites
- Java 8=>15 (Make sure to have correct JAVA_HOME setup in your environment)
- Maven
- Angular JS
- NPM
- Bulma

## How to run it
1. Clone the repository and go to the directory entitled `estore-api`.
2. Execute `mvn compile exec:java`
3. In another session: from the root directory, change directory into `estore-ui/angular-meatlab-ui`
4. If needed, run `npm install` and `npm install bulma`
5. Execute `ng serve --open` and a browser window should open up showing the site

## Known bugs and disclaimers
### Issues With Maven
Sometimes maven will not correctly compile the java project, especially if the project has been run before on the same machine but there was an update performed on the project. In the event the backend does not seem to work, run `mvn clean install` in the `estore-api` directory before running `mvn compile exec:java`. 

## How to test it

The Maven build script provides hooks for run unit tests and generate code coverage
reports in HTML.

To run tests on all tiers together do this:

1. Execute `mvn clean test jacoco:report`
2. Open in your browser the file at `PROJECT_API_HOME/target/site/jacoco/index.html`

To run tests on a single tier do this:

1. Execute `mvn clean test-compile surefire:test@tier jacoco:report@tier` where `tier` is one of `controller`, `model`, `persistence`
2. Open in your browser the file at `PROJECT_API_HOME/target/site/jacoco/{controller, model, persistence}/index.html`

To run tests on all the tiers in isolation do this:

1. Execute `mvn exec:exec@tests-and-coverage`
2. To view the Controller tier tests open in your browser the file at `PROJECT_API_HOME/target/site/jacoco/model/index.html`
3. To view the Model tier tests open in your browser the file at `PROJECT_API_HOME/target/site/jacoco/model/index.html`
4. To view the Persistence tier tests open in your browser the file at `PROJECT_API_HOME/target/site/jacoco/model/index.html`

*(Consider using `mvn clean verify` to attest you have reached the target threshold for coverage)
  
  
## How to generate the Design documentation PDF

1. Access the `PROJECT_DOCS_HOME/` directory
2. Execute `mvn exec:exec@docs`
3. The generated PDF will be in `PROJECT_DOCS_HOME/` directory


## How to setup/run/test program 
1. Tester, first obtain the Acceptance Test plan
2. IP address of target machine running the app
3. See _how to run_ section.

## License

MIT License

See LICENSE for details.
